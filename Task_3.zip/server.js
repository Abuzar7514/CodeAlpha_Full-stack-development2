const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { URL } = require('url');

const PORT = process.env.PORT || 3000;
const publicDir = path.join(__dirname, 'public');
const sessions = new Map();
const eventClients = new Set();
const db = {
  users: [
    { id: 'u1', name: 'Alex Morgan', email: 'alex@orbit.dev', password: 'demo', initials: 'AM', color: '#e7a76d' },
    { id: 'u2', name: 'Priya Shah', email: 'priya@orbit.dev', password: 'demo', initials: 'PS', color: '#9d8fe3' },
    { id: 'u3', name: 'Mateo Ruiz', email: 'mateo@orbit.dev', password: 'demo', initials: 'MR', color: '#79b9b1' }
  ],
  projects: [
    { id: 'p1', name: 'Orbit launch', description: 'A calm launch plan for the next chapter.', color: '#d97962', members: ['u1', 'u2', 'u3'] },
    { id: 'p2', name: 'Website refresh', description: 'Make the product feel unmistakably ours.', color: '#7b8fd8', members: ['u1', 'u2'] }
  ],
  tasks: [
    { id: 't1', projectId: 'p1', title: 'Finalize launch narrative', description: 'Polish the story, proof points, and final call to action.', status: 'in-progress', priority: 'high', dueDate: '2026-09-28', assignee: 'u1', comments: [{ id: 'c1', userId: 'u2', text: 'The opening is landing well. I left two notes in the doc.', createdAt: '2026-09-22T14:25:00.000Z' }] },
    { id: 't2', projectId: 'p1', title: 'Prepare partner kit', description: 'Export logos, one-pager, and the partner briefing deck.', status: 'todo', priority: 'medium', dueDate: '2026-10-01', assignee: 'u2', comments: [] },
    { id: 't3', projectId: 'p1', title: 'QA onboarding flow', description: 'Walk through the new member experience on mobile and desktop.', status: 'todo', priority: 'low', dueDate: '2026-10-03', assignee: 'u3', comments: [] },
    { id: 't4', projectId: 'p1', title: 'Send launch recap', description: 'Capture the decisions and share the follow-up with the team.', status: 'done', priority: 'medium', dueDate: '2026-09-20', assignee: 'u1', comments: [] },
    { id: 't5', projectId: 'p2', title: 'Audit current navigation', description: 'Map the existing information architecture and friction points.', status: 'in-progress', priority: 'medium', dueDate: '2026-09-26', assignee: 'u2', comments: [] },
    { id: 't6', projectId: 'p2', title: 'Collect customer quotes', description: 'Find three concise quotes from recent research calls.', status: 'todo', priority: 'low', dueDate: '2026-09-30', assignee: 'u1', comments: [] }
  ]
};

function id(prefix) { return prefix + crypto.randomBytes(4).toString('hex'); }
function json(res, status, payload) { res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(payload)); }
function parseBody(req) { return new Promise((resolve, reject) => { let body = ''; req.on('data', chunk => { body += chunk; if (body.length > 1e6) req.destroy(); }); req.on('end', () => { try { resolve(body ? JSON.parse(body) : {}); } catch { reject(new Error('Invalid JSON')); } }); }); }
function currentUser(req) { const requestUrl = new URL(req.url, 'http://localhost'); const token = (req.headers.authorization || '').replace('Bearer ', '') || requestUrl.searchParams.get('token'); const userId = sessions.get(token); return db.users.find(user => user.id === userId); }
function safeUser(user) { return user && { id: user.id, name: user.name, email: user.email, initials: user.initials, color: user.color }; }
function projectView(project) { return { ...project, memberDetails: project.members.map(id => safeUser(db.users.find(user => user.id === id))).filter(Boolean) }; }
function taskView(task) { return { ...task, assigneeDetails: safeUser(db.users.find(user => user.id === task.assignee)), comments: task.comments.map(comment => ({ ...comment, user: safeUser(db.users.find(user => user.id === comment.userId)) })) }; }
function emit(type, payload) { const message = `data: ${JSON.stringify({ type, payload })}\n\n`; eventClients.forEach(res => res.write(message)); }
function requireUser(req, res) { const user = currentUser(req); if (!user) { json(res, 401, { error: 'Please sign in to continue.' }); return null; } return user; }

async function handleApi(req, res, url) {
  if (req.method === 'POST' && url.pathname === '/api/auth/login') {
    const body = await parseBody(req); const user = db.users.find(item => item.email.toLowerCase() === String(body.email || '').toLowerCase() && item.password === body.password);
    if (!user) return json(res, 401, { error: 'That email or password is not right.' });
    const token = crypto.randomBytes(24).toString('hex'); sessions.set(token, user.id); return json(res, 200, { token, user: safeUser(user) });
  }
  if (req.method === 'POST' && url.pathname === '/api/auth/register') {
    const body = await parseBody(req); if (!body.name || !body.email || !body.password) return json(res, 400, { error: 'Name, email, and password are required.' });
    if (db.users.some(item => item.email.toLowerCase() === body.email.toLowerCase())) return json(res, 409, { error: 'An account with that email already exists.' });
    const user = { id: id('u'), name: body.name, email: body.email, password: body.password, initials: body.name.split(' ').map(part => part[0]).join('').slice(0, 2).toUpperCase(), color: '#d97962' }; db.users.push(user); const token = crypto.randomBytes(24).toString('hex'); sessions.set(token, user.id); return json(res, 201, { token, user: safeUser(user) });
  }
  const user = requireUser(req, res); if (!user) return;
  if (req.method === 'GET' && url.pathname === '/api/me') return json(res, 200, { user: safeUser(user) });
  if (req.method === 'GET' && url.pathname === '/api/bootstrap') return json(res, 200, { user: safeUser(user), projects: db.projects.map(projectView), users: db.users.map(safeUser) });
  if (req.method === 'GET' && url.pathname === '/api/events') { res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive', 'Access-Control-Allow-Origin': '*' }); res.write(`data: ${JSON.stringify({ type: 'connected' })}\n\n`); eventClients.add(res); req.on('close', () => eventClients.delete(res)); return; }
  if (req.method === 'POST' && url.pathname === '/api/projects') { const body = await parseBody(req); const project = { id: id('p'), name: body.name || 'Untitled project', description: body.description || '', color: body.color || '#d97962', members: [user.id] }; db.projects.push(project); emit('project-created', projectView(project)); return json(res, 201, projectView(project)); }
  const projectMatch = url.pathname.match(/^\/api\/projects\/([^/]+)$/);
  if (req.method === 'GET' && projectMatch) { const project = db.projects.find(item => item.id === projectMatch[1]); if (!project) return json(res, 404, { error: 'Project not found.' }); return json(res, 200, { project: projectView(project), tasks: db.tasks.filter(task => task.projectId === project.id).map(taskView) }); }
  if (req.method === 'POST' && projectMatch) { const body = await parseBody(req); const project = db.projects.find(item => item.id === projectMatch[1]); if (!project) return json(res, 404, { error: 'Project not found.' }); const task = { id: id('t'), projectId: project.id, title: body.title || 'New task', description: body.description || '', status: body.status || 'todo', priority: body.priority || 'medium', dueDate: body.dueDate || '', assignee: body.assignee || user.id, comments: [] }; db.tasks.push(task); emit('task-created', taskView(task)); return json(res, 201, taskView(task)); }
  const taskMatch = url.pathname.match(/^\/api\/tasks\/([^/]+)$/);
  if (req.method === 'PATCH' && taskMatch) { const task = db.tasks.find(item => item.id === taskMatch[1]); if (!task) return json(res, 404, { error: 'Task not found.' }); const body = await parseBody(req); Object.assign(task, { title: body.title ?? task.title, description: body.description ?? task.description, status: body.status ?? task.status, priority: body.priority ?? task.priority, dueDate: body.dueDate ?? task.dueDate, assignee: body.assignee ?? task.assignee }); emit('task-updated', taskView(task)); return json(res, 200, taskView(task)); }
  const commentsMatch = url.pathname.match(/^\/api\/tasks\/([^/]+)\/comments$/);
  if (req.method === 'POST' && commentsMatch) { const task = db.tasks.find(item => item.id === commentsMatch[1]); if (!task) return json(res, 404, { error: 'Task not found.' }); const body = await parseBody(req); if (!body.text) return json(res, 400, { error: 'Comment cannot be empty.' }); const comment = { id: id('c'), userId: user.id, text: body.text, createdAt: new Date().toISOString() }; task.comments.push(comment); emit('comment-added', taskView(task)); return json(res, 201, { ...comment, user: safeUser(user) }); }
  json(res, 404, { error: 'Not found.' });
}

function serveStatic(req, res) { let filePath = path.join(publicDir, req.url === '/' ? 'index.html' : req.url.replace(/^\//, '')); if (!filePath.startsWith(publicDir) || !fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) filePath = path.join(publicDir, 'index.html'); const types = { '.html': 'text/html', '.css': 'text/css', '.js': 'text/javascript', '.svg': 'image/svg+xml' }; res.writeHead(200, { 'Content-Type': types[path.extname(filePath)] || 'text/plain' }); fs.createReadStream(filePath).pipe(res); }
const server = http.createServer(async (req, res) => { try { const url = new URL(req.url, `http://${req.headers.host}`); if (url.pathname.startsWith('/api/')) await handleApi(req, res, url); else serveStatic(req, res); } catch (error) { json(res, 500, { error: error.message || 'Server error.' }); } });
server.listen(PORT, () => console.log(`Orbit is running at http://localhost:${PORT}`));
