const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, 'harbor-pine-db.json');
const emptyStore = { products: [], users: [], sessions: [], orders: [], orderItems: [], nextUserId: 1, nextOrderId: 1 };
let store;
try { store = JSON.parse(fs.readFileSync(filePath, 'utf8')); } catch { store = emptyStore; }
function save() { fs.writeFileSync(filePath, JSON.stringify(store, null, 2)); }
function seedProducts(products) { if (store.products.length) return; store.products = products.map((product) => ({ ...product })); save(); }
function getProducts() { return store.products; }
function getProduct(id) { return store.products.find((product) => product.id === id); }
function createUser(name, email, passwordHash) {
  if (store.users.some((user) => user.email.toLowerCase() === email.toLowerCase())) { const error = new Error('Duplicate email'); error.code = 'DUPLICATE_EMAIL'; throw error; }
  const user = { id: store.nextUserId++, name, email, passwordHash, createdAt: new Date().toISOString() };
  store.users.push(user); save(); return { id: user.id, name: user.name, email: user.email };
}
function getUserByEmail(email) { return store.users.find((user) => user.email.toLowerCase() === email.toLowerCase()); }
function createSession(token, userId) { store.sessions = store.sessions.filter((session) => session.expiresAt > Date.now()); store.sessions.push({ token, userId, expiresAt: Date.now() + 7 * 24 * 60 * 60 * 1000 }); save(); }
function getSessionUser(token) { const session = store.sessions.find((item) => item.token === token && item.expiresAt > Date.now()); const user = session && store.users.find((item) => item.id === session.userId); return user ? { id: user.id, name: user.name, email: user.email } : null; }
function deleteSession(token) { store.sessions = store.sessions.filter((session) => session.token !== token); save(); }
function createOrder(order) { const savedOrder = { id: store.nextOrderId++, ...order, createdAt: new Date().toISOString() }; store.orders.push({ ...savedOrder, items: undefined }); savedOrder.items.forEach((item) => store.orderItems.push({ orderId: savedOrder.id, ...item })); save(); }
function getAdminSummary() {
  const users = store.users.map(({ id, name, email, createdAt }) => ({ id, name, email, createdAt })).sort((a, b) => b.id - a.id);
  const orders = store.orders.map((order) => ({ ...order, user: users.find((user) => user.id === order.userId) || { name: 'Unknown customer', email: '' }, itemCount: store.orderItems.filter((item) => item.orderId === order.id).reduce((sum, item) => sum + item.quantity, 0) })).sort((a, b) => b.id - a.id);
  return { metrics: { customers: users.length, orders: orders.length, revenue: orders.reduce((sum, order) => sum + order.total, 0), products: store.products.length }, users, orders };
}
module.exports = { seedProducts, getProducts, getProduct, createUser, getUserByEmail, createSession, getSessionUser, deleteSession, createOrder, getAdminSummary };
