const express = require('express');
const path = require('path');
const crypto = require('crypto');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;
const adminSessions = new Set();
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'admin@harborpine.local';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin12345';

const products = [
  {
    id: 1,
    name: 'Cedar Ridge Jacket',
    category: 'Outerwear',
    price: 148,
    rating: 4.9,
    badge: 'Best seller',
    description: 'A weather-ready layer cut from recycled ripstop with a warm, quilted lining and a relaxed everyday fit.',
    colors: ['Moss', 'Navy', 'Clay'],
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    image: 'https://images.unsplash.com/photo-1523381210434-271e8be1f52b?auto=format&fit=crop&w=1000&q=85'
  },
  {
    id: 2,
    name: 'Alpine Knit',
    category: 'Knitwear',
    price: 92,
    rating: 4.8,
    badge: 'New arrival',
    description: 'Soft merino wool with a gently structured shape, made for slow mornings and cool-weather walks.',
    colors: ['Oat', 'Fern', 'Charcoal'],
    sizes: ['S', 'M', 'L', 'XL'],
    image: 'https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=1000&q=85'
  },
  {
    id: 3,
    name: 'Field Day Tote',
    category: 'Accessories',
    price: 58,
    rating: 4.7,
    badge: 'Everyday essential',
    description: 'A generous canvas carryall with a sturdy leather handle and room for the whole day.',
    colors: ['Natural', 'Ink'],
    sizes: ['One size'],
    image: 'https://images.unsplash.com/photo-1594223274512-ad4803739b7c?auto=format&fit=crop&w=1000&q=85'
  },
  {
    id: 4,
    name: 'Riverside Sneaker',
    category: 'Footwear',
    price: 124,
    rating: 4.9,
    badge: 'Customer favorite',
    description: 'A low-profile everyday sneaker with a cushioned footbed and responsibly sourced canvas upper.',
    colors: ['Bone', 'Pine', 'Ink'],
    sizes: ['6', '7', '8', '9', '10', '11'],
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=1000&q=85'
  },
  {
    id: 5,
    name: 'Trailside Cap',
    category: 'Accessories',
    price: 36,
    rating: 4.6,
    badge: 'Just in',
    description: 'Washed cotton twill, a curved brim and an adjustable back for easy, all-day comfort.',
    colors: ['Cobalt', 'Clay', 'Pine'],
    sizes: ['One size'],
    image: 'https://images.unsplash.com/photo-1521369909029-2afed882baee?auto=format&fit=crop&w=1000&q=85'
  },
  {
    id: 6,
    name: 'Cairn Watch',
    category: 'Accessories',
    price: 185,
    rating: 4.8,
    badge: 'Limited run',
    description: 'A quiet, considered timepiece with a brushed steel case and vegetable-tanned leather strap.',
    colors: ['Steel', 'Brass'],
    sizes: ['One size'],
    image: 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=1000&q=85'
  }
];

db.seedProducts(products);

function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  return new Promise((resolve, reject) => crypto.scrypt(password, salt, 64, (error, derivedKey) => error ? reject(error) : resolve(`${salt}:${derivedKey.toString('hex')}`)));
}

function verifyPassword(password, storedHash) {
  const [salt, key] = storedHash.split(':');
  return new Promise((resolve, reject) => crypto.scrypt(password, salt, 64, (error, derivedKey) => {
    if (error) return reject(error);
    resolve(crypto.timingSafeEqual(Buffer.from(key, 'hex'), derivedKey));
  }));
}

function sessionCookie(token) { return `hp_session=${token}; HttpOnly; Path=/; SameSite=Lax; Max-Age=604800`; }
function getSessionUser(req) {
  const token = req.headers.cookie?.split(';').map((item) => item.trim()).find((item) => item.startsWith('hp_session='))?.split('=')[1];
  if (!token) return null;
  return db.getSessionUser(token);
}
function getAdminToken(req) {
  return req.headers.cookie?.split(';').map((item) => item.trim()).find((item) => item.startsWith('hp_admin='))?.split('=')[1];
}
function requireAdmin(req, res, next) {
  if (!adminSessions.has(getAdminToken(req))) return res.status(401).json({ error: 'Admin sign-in required.' });
  next();
}

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.post('/api/admin/login', (req, res) => {
  const { email, password } = req.body;
  if (email !== ADMIN_EMAIL || password !== ADMIN_PASSWORD) return res.status(401).json({ error: 'Admin email or password is incorrect.' });
  const token = crypto.randomBytes(32).toString('hex');
  adminSessions.add(token);
  res.setHeader('Set-Cookie', `hp_admin=${token}; HttpOnly; Path=/; SameSite=Lax; Max-Age=28800`);
  res.json({ ok: true });
});
app.post('/api/admin/logout', (req, res) => {
  adminSessions.delete(getAdminToken(req));
  res.setHeader('Set-Cookie', 'hp_admin=; HttpOnly; Path=/; Max-Age=0');
  res.status(204).end();
});
app.get('/api/admin/summary', requireAdmin, (_req, res) => res.json(db.getAdminSummary()));

app.get('/api/products', (_req, res) => res.json(db.getProducts()));
app.get('/api/products/:id', (req, res) => {
  const product = db.getProduct(Number(req.params.id));
  product ? res.json(product) : res.status(404).json({ error: 'Product not found' });
});

app.get('/api/auth/me', (req, res) => res.json({ user: getSessionUser(req) }));

app.post('/api/auth/register', async (req, res) => {
  const { name, email, password } = req.body;
  if (!name?.trim() || !email?.trim() || !password || password.length < 8) return res.status(400).json({ error: 'Name, email, and a password of at least 8 characters are required.' });
  try {
    const user = db.createUser(name.trim(), email.trim(), await hashPassword(password));
    const token = crypto.randomBytes(32).toString('hex');
    db.createSession(token, user.id);
    res.setHeader('Set-Cookie', sessionCookie(token));
    res.status(201).json({ user });
  } catch (error) {
    res.status(error.code === 'DUPLICATE_EMAIL' ? 409 : 500).json({ error: error.code === 'DUPLICATE_EMAIL' ? 'An account with that email already exists.' : 'Could not create account.' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  const user = email ? db.getUserByEmail(email.trim()) : null;
  if (!user || !password || !(await verifyPassword(password, user.passwordHash))) return res.status(401).json({ error: 'Email or password is incorrect.' });
  const token = crypto.randomBytes(32).toString('hex');
  db.createSession(token, user.id);
  res.setHeader('Set-Cookie', sessionCookie(token));
  res.json({ user: { id: user.id, name: user.name, email: user.email } });
});

app.post('/api/auth/logout', (req, res) => {
  const token = req.headers.cookie?.split(';').map((item) => item.trim()).find((item) => item.startsWith('hp_session='))?.split('=')[1];
  if (token) db.deleteSession(token);
  res.setHeader('Set-Cookie', 'hp_session=; HttpOnly; Path=/; Max-Age=0');
  res.status(204).end();
});

app.post('/api/orders', (req, res) => {
  const user = getSessionUser(req);
  const { address, items } = req.body;
  if (!user) return res.status(401).json({ error: 'Please sign in before placing an order.' });
  if (!address || !Array.isArray(items) || items.length === 0) return res.status(400).json({ error: 'Please provide a delivery address and at least one item.' });

  const lineItems = items.map((item) => {
    const product = db.getProduct(Number(item.productId));
    return product ? { productId: product.id, name: product.name, quantity: Math.max(1, Number(item.quantity) || 1), price: product.price } : null;
  }).filter(Boolean);

  const total = lineItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const orderNumber = `HP-${Date.now().toString().slice(-8)}`;
  db.createOrder({ orderNumber, userId: user.id, address: address.trim(), total, status: 'confirmed', items: lineItems });

  res.status(201).json({ orderNumber, customer: { name: user.name }, items: lineItems, total, status: 'confirmed' });
});

app.get('/admin', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));
app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.listen(PORT, () => console.log(`Abuzar Jan Store running at http://localhost:${PORT}`));
